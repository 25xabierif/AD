public enum Hechizo {
    adivinación, necromancia, piromancia, invocación
}
