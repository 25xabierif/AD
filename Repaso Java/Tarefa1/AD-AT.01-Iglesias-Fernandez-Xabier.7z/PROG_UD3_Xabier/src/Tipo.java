public enum Tipo {
    orgro, troll, espectro
}
